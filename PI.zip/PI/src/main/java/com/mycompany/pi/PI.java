/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pi;

/**
 *
 * @author angelo.bferreira
 */
public class PI {

    public static void main(String[] args) {
        new CadastroCliente().setVisible(true);
    }
}
