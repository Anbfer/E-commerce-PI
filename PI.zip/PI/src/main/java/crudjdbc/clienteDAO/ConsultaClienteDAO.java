/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crudjdbc.clienteDAO;

import classeCliente.Cliente;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * (DAO) para consulta de objetos Cliente no banco de dados.
 * Esta classe fornece métodos para pesquisar, excluir e listar objetos Cliente.
 * Também possui métodos auxiliares para preencher tabelas JTable com os resultados da pesquisa.
 * Todos os métodos desta classe são estáticos.
 * 
 * @author Angelo
 */
public class ConsultaClienteDAO {
    
     /**
     * Pesquisa todos os clientes no banco de dados e preenche a tabela JTable com os resultados.
     * 
     * @param tabela A tabela JTable onde os resultados serão exibidos.
     */
    public static void pesquisar(JTable tabela) {

        ArrayList<Cliente> lista = ConsultaClienteDAO.listarCliente();

        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
        modelo.setRowCount(0);
        //Percorrer a lista e adicionar a tabela
        for (Cliente consumidor : lista) {
            modelo.addRow(new String[]{String.valueOf(consumidor.getId()), consumidor.getNome(), consumidor.getGenero(), consumidor.getCpf(), consumidor.getEmail(), consumidor.getEndereco(), consumidor.getTelefone()});
        }

    }
    
    /**
     * Pesquisa clientes com base no nome informado e preenche a tabela JTable com os resultados.
     * 
     * @param tabela A tabela JTable onde os resultados serão exibidos.
     * @param nome O nome a ser pesquisado.
     */
    public static void pesquisar(JTable tabela, String nome) {

        ArrayList<Cliente> lista = ConsultaClienteDAO.listarClienteNome(nome);

        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
        modelo.setRowCount(0);
        //Percorrer a lista e adicionar a tabela
        for (Cliente consumidor : lista) {
            modelo.addRow(new String[]{String.valueOf(consumidor.getId()), consumidor.getNome(), consumidor.getGenero(), consumidor.getCpf(), consumidor.getEmail(), consumidor.getEndereco(), consumidor.getTelefone()});
        }
    }
    
    /**
     * Exclui o cliente selecionado na tabela JTable.
     * 
     * @param tabela A tabela JTable onde o cliente está sendo exibido.
     */
    public static void excluir(JTable tabela){
        int linhaEscolhida = tabela.getSelectedRow();
        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();

        //remove do banco
        int id = Integer.parseInt(tabela.getValueAt(linhaEscolhida, 0).toString());

        boolean retorno = ConsultaClienteDAO.excluirCliente(id);
        if (retorno) {
            //Remove da tabela
            modelo.removeRow(linhaEscolhida);
            JOptionPane.showMessageDialog(null, "Registro excluido com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Falha ao excluir registro!");
        }
    }
    
    /**
     * Pesquisa clientes com base no CPF informado e preenche a tabela JTable com os resultados.
     * 
     * @param tabela A tabela JTable onde os resultados serão exibidos.
     * @param cpf O CPF a ser pesquisado.
     */
    public static void pesquisarCpf(JTable tabela, String cpf) {

        ArrayList<Cliente> lista = ConsultaClienteDAO.listarClienteCpf(cpf);

        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
        modelo.setRowCount(0);
        //Percorrer a lista e adicionar a tabela
        for (Cliente consumidor : lista) {
            modelo.addRow(new String[]{String.valueOf(consumidor.getId()), consumidor.getNome(), consumidor.getGenero(), consumidor.getCpf(), consumidor.getEmail(), consumidor.getEndereco(), consumidor.getTelefone()});
        }

    }

    /**
     * Lista todos os clientes no banco de dados.
     * @param nome
     * @return A lista de clientes encontrados.
     */
    public static ArrayList<Cliente> listarClienteNome(String nome) {
        ArrayList<Cliente> listaRetorno = new ArrayList<>();
        Connection conexao = null;

        try {
            //Carregar Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/javamarketbd";

            //Passo 2 - Abrir a conexao
            conexao = DriverManager.getConnection(url, "root", "admin");

            //Passo 3 - Preparar o comando SQL
            PreparedStatement comandoSQL
                    = conexao.prepareStatement("SELECT * FROM cliente WHERE nomeClie LIKE ?");

            comandoSQL.setString(1, "%" + nome + "%");

            //Passo 4 - Executar o comando SQL
            ResultSet rs = comandoSQL.executeQuery();

            if (rs != null) {
                //Percorro o resultset ("tabela" na memória)
                //e passo os valores a um objeto
                while (rs.next()) {
                    Cliente cliente = new Cliente();
                    cliente.setId(rs.getInt("id_cliente"));
                    cliente.setNome(rs.getString("nomeClie"));
                    cliente.setCpf(rs.getString("cpf"));
                    cliente.setGenero(rs.getString("genero"));
                    cliente.setEmail(rs.getString("email"));
                    cliente.setEndereco(rs.getString("endereco"));
                    cliente.setTelefone(rs.getString("telefone"));

                    listaRetorno.add(cliente);

                }
            }

        } catch (ClassNotFoundException ex) {
            System.out.println("Erro ao carregar o Driver" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Erro ao abrir a conexao" + ex.getMessage());
        }

        return listaRetorno;

    }
    
    /**
     * Lista todos os clientes no banco de dados com base no CPF.
     * 
     * @param cpf O CPF a ser pesquisado.
     * @return A lista de clientes encontrados.
     */
    public static ArrayList<Cliente> listarClienteCpf(String cpf) {
        ArrayList<Cliente> listaRetorno = new ArrayList<>();
        Connection conexao = null;

        try {
            //Carregar Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/javamarketbd";

            //Passo 2 - Abrir a conexao
            conexao = DriverManager.getConnection(url, "root", "admin");

            //Passo 3 - Preparar o comando SQL
            PreparedStatement comandoSQL
                    = conexao.prepareStatement("SELECT * FROM cliente WHERE cpf LIKE ?");

            comandoSQL.setString(1, "%" + cpf + "%");

            //Passo 4 - Executar o comando SQL
            ResultSet rs = comandoSQL.executeQuery();

            if (rs != null) {
                //Percorro o resultset ("tabela" na memória)
                //e passo os valores a um objeto
                while (rs.next()) {
                    Cliente cliente = new Cliente();
                    cliente.setId(rs.getInt("id_cliente"));
                    cliente.setNome(rs.getString("nomeClie"));
                    cliente.setCpf(rs.getString("cpf"));
                    cliente.setGenero(rs.getString("genero"));
                    cliente.setEmail(rs.getString("email"));
                    cliente.setEndereco(rs.getString("endereco"));
                    cliente.setTelefone(rs.getString("telefone"));

                    listaRetorno.add(cliente);

                }
            }

        } catch (ClassNotFoundException ex) {
            System.out.println("Erro ao carregar o Driver" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Erro ao abrir a conexao" + ex.getMessage());
        }

        return listaRetorno;

    }
    
    /**
     * Lista todos os clientes no banco de dados.
     * 
     * @return A lista de clientes encontrados.
     */
    public static ArrayList<Cliente> listarCliente() {
        ArrayList<Cliente> listaRetorno = new ArrayList<>();
        Connection conexao = null;

        try {
            //Carregar Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/javamarketbd";

            //Passo 2 - Abrir a conexao
            conexao = DriverManager.getConnection(url, "root", "admin");

            //Passo 3 - Preparar o comando SQL
            PreparedStatement comandoSQL
                    = conexao.prepareStatement("SELECT * FROM cliente");

            //Passo 4 - Executar o comando SQL
            ResultSet rs = comandoSQL.executeQuery();

            if (rs != null) {
                //Percorro o resultset ("tabela" na memória)
                //e passo os valores a um objeto
                while (rs.next()) {
                    Cliente cliente = new Cliente();
                    cliente.setId(rs.getInt("id_cliente"));
                    cliente.setNome(rs.getString("nomeClie"));
                    cliente.setGenero(rs.getString("genero"));
                    cliente.setCpf(rs.getString("cpf"));
                    cliente.setEmail(rs.getString("email"));
                    cliente.setEndereco(rs.getString("endereco"));
                    cliente.setTelefone(rs.getString("telefone"));

                    listaRetorno.add(cliente);

                }
            }
        } catch (ClassNotFoundException ex) {
            System.out.println("Erro ao carregar o Driver" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Erro ao abrir a conexao" + ex.getMessage());
        }

        return listaRetorno;

    }//Fim do método listar

    /**
     * Altera as informações de um cliente no banco de dados.
     * 
     * @param cliente O cliente com as informações atualizadas.
     * @return True se a alteração foi bem-sucedida, False caso contrário.
     */
    public static boolean alterarCliente(Cliente cliente) {
        boolean retorno = false;
        Connection conexao = null;

        try {
            //Carregar Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/javamarketbd";

            //Passo 2 - Abrir a conexao
            conexao = DriverManager.getConnection(url, "root", "admin");

            //Passo 3 - Prepara o comando SQL
            PreparedStatement comandoSQL = conexao.prepareStatement("UPDATE cliente SET nomeClie = ?, genero = ?, cpf = ?, email = ?, endereco = ?, telefone = ? where id_cliente = ?");

            comandoSQL.setString(1, cliente.getNome());
            comandoSQL.setString(2, cliente.getGenero());
            comandoSQL.setString(3, cliente.getCpf());
            comandoSQL.setString(4, cliente.getEmail());
            comandoSQL.setString(5, cliente.getEndereco());
            comandoSQL.setString(6, cliente.getTelefone());
            comandoSQL.setInt(7, cliente.getId());

            //Passo 4 - Executar comando SQL
            int linhasAfetadas = comandoSQL.executeUpdate();

            if (linhasAfetadas > 0) {
                retorno = true;
            }

        } catch (ClassNotFoundException ex) {
            System.out.println("Erro ao carregar o Driver" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Erro ao abrir a conexao" + ex.getMessage());
        }

        return retorno;

    }//Fim metodo alterar
    
    /**
     * Exclui um cliente do banco de dados.
     * 
     * @param id O ID do cliente a ser excluído.
     * @return True se a exclusão foi bem-sucedida, False caso contrário.
     */
    public static boolean excluirCliente(int id) {

        boolean retorno = false;
        Connection conexao = null;

        try {
            //Passo 1 - Carregaro o Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/javamarketbd";

            //Passo 2 - Abrir a conexao
            conexao = DriverManager.getConnection(url, "root", "admin");

            //Passo 3 - Prepara o comando SQL
            PreparedStatement comandoSQL
                    = conexao.prepareStatement("DELETE FROM cliente WHERE id_cliente = ? ");

            comandoSQL.setInt(1, id);

            //Passo 4 - Executar comando SQL
            int linhasAfetadas = comandoSQL.executeUpdate();

            if (linhasAfetadas > 0) {
                retorno = true;
            }

        } catch (ClassNotFoundException ex) {
            System.out.println("Erro ao carregar o Driver" + ex.getMessage());
        } catch (SQLException ex) {
            System.out.println("Erro ao abrir a conexao" + ex.getMessage());
        }

        return retorno;
    }//fim metodo excluir
}
